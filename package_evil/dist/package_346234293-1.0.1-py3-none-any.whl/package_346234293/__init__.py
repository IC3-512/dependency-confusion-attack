from .example import add, cos
print("evil code execution in __init__.py")